package com.stockpro

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Fondo ambiental compartido para mantener una identidad visual consistente en todos los módulos. */
internal fun Modifier.stockProBackdrop(): Modifier = drawBehind {
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFF08151A), Color(0xFF050A0D), Color(0xFF06110D)),
            startY = 0f,
            endY = size.height.coerceAtLeast(1f)
        )
    )
    val radius = size.maxDimension * 0.72f
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x2427D9C3), Color(0x0A27D9C3), Color.Transparent),
            center = Offset(size.width * 0.96f, size.height * 0.05f),
            radius = radius.coerceAtLeast(1f)
        ),
        radius = radius,
        center = Offset(size.width * 0.96f, size.height * 0.05f)
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x1648F2A0), Color.Transparent),
            center = Offset(size.width * 0.02f, size.height * 0.92f),
            radius = radius.coerceAtLeast(1f)
        ),
        radius = radius,
        center = Offset(size.width * 0.02f, size.height * 0.92f)
    )
}
