# Estado de StockPro Premium

## Última actualización visual
- Sistema de diseño Material 3 centralizado con paleta oscura esmeralda/cian, tipografía y formas coherentes.
- Navegación y barras del sistema ajustadas a la identidad oscura.
- Inventario con fondo de marca y filtros con estados activos diferenciados.
- Formulario de alta inicia con SKU calculado por familia; la numeración se calcula frente a las referencias existentes.
- Biblioteca local de imágenes de producto y selección/sugerencia por categoría documentadas en `BIBLIOTECA_ICONOS_PRODUCTOS.md`.

## Pendiente de validación
- Ejecutar `gradle assembleDebug` en GitHub Actions.
- Resolver cualquier error de compilación que aparezca en el log real.
- Instalar la APK resultante en Android y revisar tamaños, barras del sistema, formulario, inventario y biblioteca visual.
- No considerar validada la APK hasta que estas pruebas terminen con éxito.

## Diseño transversal
El archivo `app/src/main/java/com/stockpro/PremiumDesign.kt` define `Modifier.stockProBackdrop()`, compartido por los módulos principales. Las pantallas con scroll conservan su estructura y lógica de negocio. Pendiente compilar con GitHub Actions y revisar contraste/recorte en teléfonos de distintos tamaños.
